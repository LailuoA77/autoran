---
name: Feature request（需求）
about: 建议或需求
title: "【建议】请清晰地描述你的建议内容"
labels: 需求/feature
assignees: ''

---

建议内容：
（提issue前请确认没有其他人提过相同的，重复提交会被删除，严重的会进行拉黑处理！）
